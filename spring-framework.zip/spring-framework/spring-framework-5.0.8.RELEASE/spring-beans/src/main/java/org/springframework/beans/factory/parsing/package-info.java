/**
 * Support infrastructure for bean definition parsing.
 */
@NonNullApi
@NonNullFields
package org.springframework.beans.factory.parsing;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
